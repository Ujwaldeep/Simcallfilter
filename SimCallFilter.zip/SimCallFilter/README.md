# SIM Call Filter

Rejects incoming calls from numbers NOT in your contacts, but only on the SIM slot you pick.
The other SIM is never touched.

## Build
1. Install Android Studio (latest). Open this folder (File > Open).
2. Let Gradle sync (it downloads Gradle 8.7 + Android SDK 34 if missing).
3. Build > Build APK(s). Output: app/build/outputs/apk/debug/app-debug.apk
   (or plug in the S23 with USB debugging on and press Run)

## Setup on the phone
1. Install the APK (allow "install unknown apps" if sideloading).
2. Open "SIM Call Filter":
   - Tap "Grant contacts + phone permissions" > Allow
   - Tap "Set as call screening app" > choose SIM Call Filter
   - Pick SIM 1 or SIM 2 under "SIM to filter"
3. Test: call the filtered SIM from an unsaved number, then check "Recent decisions".

## Safety behaviour
If the app can't work out which SIM a call came on, or hits any error, the call is ALLOWED.
Check the log after a test call: you want to see "SIM 1" / "SIM 2", not "SIM unknown".

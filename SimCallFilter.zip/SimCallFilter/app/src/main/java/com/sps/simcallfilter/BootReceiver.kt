package com.sps.simcallfilter

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) {
            runCatching { ctx.startForegroundService(Intent(ctx, RingWatcherService::class.java)) }
        }
    }
}

package com.sps.simcallfilter

import android.app.Application

/** Saves any crash stack trace so the next launch can show it. */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                getSharedPreferences("crash", MODE_PRIVATE).edit()
                    .putString("trace", android.util.Log.getStackTraceString(e))
                    .commit()
            } catch (x: Throwable) {
            }
            prev?.uncaughtException(t, e)
        }
    }
}

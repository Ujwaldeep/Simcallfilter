package com.sps.simcallfilter

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.telephony.SubscriptionManager
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager

/**
 * Listens to each SIM's own call state. When a SIM goes RINGING we remember its slot,
 * which is how the screening service learns which SIM an incoming call is on.
 */
class RingWatcherService : Service() {

    private val regs = mutableListOf<Pair<TelephonyManager, TelephonyCallback>>()

    private class Cb(val slot: Int, val ctx: Context) :
        TelephonyCallback(), TelephonyCallback.CallStateListener {
        override fun onCallStateChanged(state: Int) {
            val name = when (state) {
                TelephonyManager.CALL_STATE_RINGING -> "RINGING"
                TelephonyManager.CALL_STATE_OFFHOOK -> "OFFHOOK"
                else -> "IDLE"
            }
            if (state == TelephonyManager.CALL_STATE_RINGING) Prefs.setRing(ctx, slot)
            Prefs.log(ctx, "DEBUG SIM ${slot + 1} state=$name")
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            startAsForeground()
            register()
        } catch (e: Exception) {
            Prefs.log(this, "DEBUG watcher failed: ${e.javaClass.simpleName} ${e.message}")
        }
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("watch", "Call filter", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, "watch")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("SIM Call Filter is running")
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
    }

    private fun register() {
        unregister()
        val sm = getSystemService(SubscriptionManager::class.java)
        val base = getSystemService(TelephonyManager::class.java)
        val subs = try {
            sm.activeSubscriptionInfoList
        } catch (e: SecurityException) {
            null
        }
        if (subs == null) {
            Prefs.log(this, "DEBUG watcher: no phone permission / no SIMs")
            return
        }
        for (s in subs) {
            try {
                val tm = base.createForSubscriptionId(s.subscriptionId)
                val cb = Cb(s.simSlotIndex, applicationContext)
                tm.registerTelephonyCallback(mainExecutor, cb)
                regs.add(tm to cb)
            } catch (e: Exception) {
                Prefs.log(this, "DEBUG watcher error: ${e.javaClass.simpleName}")
            }
        }
        Prefs.log(this, "DEBUG watcher registered on ${regs.size} SIM(s)")
    }

    private fun unregister() {
        regs.forEach { (tm, cb) -> runCatching { tm.unregisterTelephonyCallback(cb) } }
        regs.clear()
    }

    override fun onDestroy() {
        unregister()
        super.onDestroy()
    }
}

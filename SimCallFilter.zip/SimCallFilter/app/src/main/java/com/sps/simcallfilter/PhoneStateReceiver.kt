package com.sps.simcallfilter

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager

/** Records which SIM slot is ringing, so the screening service can use it. */
class PhoneStateReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        if (i.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        if (i.getStringExtra(TelephonyManager.EXTRA_STATE) != TelephonyManager.EXTRA_STATE_RINGING) return

        val ex = i.extras
        fun num(k: String): Int? = (ex?.get(k) as? Number)?.toInt()

        var slot = listOf("slot", "android.telephony.extra.SLOT_INDEX", "simSlot")
            .firstNotNullOfOrNull { num(it) } ?: -1
        if (slot !in 0..3) slot = -1

        if (slot == -1) {
            val subId = listOf("subscription", "android.telephony.extra.SUBSCRIPTION_INDEX", "subscription_id")
                .firstNotNullOfOrNull { num(it) }
            if (subId != null) {
                slot = runCatching {
                    ctx.getSystemService(SubscriptionManager::class.java)
                        .getActiveSubscriptionInfo(subId)?.simSlotIndex
                }.getOrNull() ?: -1
            }
        }

        if (slot != -1) Prefs.setRing(ctx, slot)

        val extrasStr = ex?.keySet()
            ?.filter { it != "incoming_number" }
            ?.joinToString { k -> "$k=${ex.get(k)}" }
        Prefs.log(ctx, "DEBUG ringing slot=${if (slot == -1) "?" else (slot + 1).toString()} extras=$extrasStr")
    }
}

package com.sps.simcallfilter

import android.app.Notification
import android.app.PendingIntent
import android.net.Uri
import android.provider.ContactsContract
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Optional: declines incoming WhatsApp calls from numbers that are not saved contacts,
 * by pressing the notification's "Decline" button. Does nothing unless the user turns it on.
 */
class WhatsAppCallService : NotificationListenerService() {

    private val handled = HashMap<String, Long>()

    override fun onListenerConnected() {
        if (!Prefs.waBlock(this)) runCatching { requestUnbind() }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            if (!Prefs.waBlock(this) || !Prefs.enabled(this)) return
            if (sbn.packageName != "com.whatsapp" && sbn.packageName != "com.whatsapp.w4b") return

            val n = sbn.notification
            if (n.category != Notification.CATEGORY_CALL) return
            val actions = n.actions ?: return
            val titles = actions.map { it.title?.toString()?.lowercase() ?: "" }
            val incoming = titles.any { it.contains("answer") || it.contains("accept") }
            if (!incoming) return

            val now = System.currentTimeMillis()
            handled.entries.removeAll { now - it.value > 10_000 }
            if (handled.containsKey(sbn.key)) return
            handled[sbn.key] = now

            val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: return
            val digits = title.filter { it.isDigit() }
            val looksUnsaved = title.startsWith("~") ||
                (digits.length >= 7 && title.none { it.isLetter() })

            if (!looksUnsaved) {
                Prefs.log(this, "ALLOWED (WhatsApp, saved) $title")
                return
            }

            val number = if (digits.length >= 7) title.filter { it.isDigit() || it == '+' } else null

            if (number != null) {
                if (Prefs.whitelist(this).any { Prefs.matches(it, number) }) {
                    Prefs.log(this, "ALLOWED (WhatsApp, whitelisted) $number")
                    return
                }
                if (isSaved(number)) {
                    Prefs.log(this, "ALLOWED (WhatsApp, saved) $number")
                    return
                }
            }

            val decline = actions.firstOrNull { a ->
                val t = a.title?.toString()?.lowercase() ?: ""
                t.contains("decline") || t.contains("reject")
            }
            if (decline == null) {
                Prefs.log(this, "DEBUG WhatsApp call from $title but no decline button found: $titles")
                return
            }

            try {
                decline.actionIntent.send()
            } catch (e: PendingIntent.CanceledException) {
                Prefs.log(this, "DEBUG WhatsApp decline failed: cancelled")
                return
            }
            cancelNotification(sbn.key)
            Prefs.countBlock(this)
            Prefs.log(this, "BLOCKED (WhatsApp) ${number ?: title}")
        } catch (e: Exception) {
            Prefs.log(this, "DEBUG WhatsApp listener error: ${e.javaClass.simpleName}")
        }
    }

    private fun isSaved(number: String): Boolean {
        val uri = Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
            Uri.encode(number)
        )
        contentResolver.query(
            uri, arrayOf(ContactsContract.PhoneLookup._ID), null, null, null
        )?.use { return it.count > 0 }
        return false
    }
}

package com.sps.simcallfilter

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    fun enabled(c: Context) = sp(c).getBoolean("enabled", true)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    /** 0-based SIM slot to filter (0 = SIM 1, 1 = SIM 2). */
    fun slot(c: Context) = sp(c).getInt("slot", 0)
    fun setSlot(c: Context, v: Int) = sp(c).edit().putInt("slot", v).apply()

    fun blockPrivate(c: Context) = sp(c).getBoolean("blockPrivate", true)
    fun setBlockPrivate(c: Context, v: Boolean) = sp(c).edit().putBoolean("blockPrivate", v).apply()

    /** Slot that most recently started ringing (from the PHONE_STATE broadcast). */
    fun setRing(c: Context, slot: Int) =
        sp(c).edit().putInt("ringSlot", slot).putLong("ringTime", System.currentTimeMillis()).apply()

    fun ringSlotSince(c: Context, since: Long): Int =
        if (sp(c).getLong("ringTime", 0L) >= since) sp(c).getInt("ringSlot", -1) else -1

    fun log(c: Context, line: String) {
        val ts = SimpleDateFormat("dd MMM HH:mm:ss", Locale.getDefault()).format(Date())
        val all = (listOf("$ts  $line") + logs(c)).take(40)
        sp(c).edit().putString("log", all.joinToString("\n")).apply()
    }

    fun logs(c: Context): List<String> =
        sp(c).getString("log", "")!!.split("\n").filter { it.isNotBlank() }

    fun clearLog(c: Context) = sp(c).edit().remove("log").apply()
}

package com.sps.simcallfilter

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    fun enabled(c: Context) = sp(c).getBoolean("enabled", true)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    /** 0-based SIM slot to filter (0 = SIM 1, 1 = SIM 2). */
    fun slot(c: Context) = sp(c).getInt("slot", 0)
    fun setSlot(c: Context, v: Int) = sp(c).edit().putInt("slot", v).apply()

    fun blockPrivate(c: Context) = sp(c).getBoolean("blockPrivate", true)
    fun setBlockPrivate(c: Context, v: Boolean) = sp(c).edit().putBoolean("blockPrivate", v).apply()

    /** Remember when a SIM slot started ringing. */
    fun setRing(c: Context, slot: Int) =
        sp(c).edit().putLong("ring$slot", System.currentTimeMillis()).apply()

    /** The single slot that rang since [since], or -1 if none or ambiguous (several slots). */
    fun ringSlotSince(c: Context, since: Long): Int {
        val hits = (0..3).filter { sp(c).getLong("ring$it", 0L) >= since }
        return if (hits.size == 1) hits[0] else -1
    }

    /** Optional always-on watcher service. Default OFF to save battery. */
    fun alwaysOn(c: Context) = sp(c).getBoolean("alwaysOn", false)
    fun setAlwaysOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("alwaysOn", v).apply()

    /** Hide blocked calls from call log / missed-call alerts. Default ON. */
    fun hideBlocked(c: Context) = sp(c).getBoolean("hideBlocked", true)
    fun setHideBlocked(c: Context, v: Boolean) = sp(c).edit().putBoolean("hideBlocked", v).apply()

    // ---------- whitelist / blocklist (apply on the filtered SIM only) ----------

    private fun list(c: Context, key: String): List<String> =
        sp(c).getString(key, "")!!.split("\n").filter { it.isNotBlank() }

    private fun addTo(c: Context, key: String, entry: String): Boolean {
        val v = entry.trim()
        if (v.filter { it.isDigit() }.isEmpty()) return false
        val l = list(c, key)
        if (!l.contains(v)) sp(c).edit().putString(key, (l + v).joinToString("\n")).apply()
        return true
    }

    private fun removeFrom(c: Context, key: String, entry: String) =
        sp(c).edit().putString(key, list(c, key).filter { it != entry }.joinToString("\n")).apply()

    fun whitelist(c: Context) = list(c, "white")
    fun addWhitelist(c: Context, e: String) = addTo(c, "white", e)
    fun removeWhitelist(c: Context, e: String) = removeFrom(c, "white", e)

    fun blocklist(c: Context) = list(c, "black")
    fun addBlocklist(c: Context, e: String) = addTo(c, "black", e)
    fun removeBlocklist(c: Context, e: String) = removeFrom(c, "black", e)

    private fun core(digits: String): String {
        var d = digits
        if (d.length > 10 && d.startsWith("91")) d = d.substring(2)
        return d.trimStart('0')
    }

    /** Entry "+91 98765 43210" matches that number in any format. Entry ending in * is a prefix. */
    fun matches(entry: String, number: String): Boolean {
        val eRaw = entry.filter { it.isDigit() }
        val eCore = core(eRaw)
        if (eCore.isEmpty()) return false
        val nRaw = number.filter { it.isDigit() }
        val nCore = core(nRaw)
        return if (entry.trim().endsWith("*")) {
            nRaw.startsWith(eRaw) || nCore.startsWith(eCore)
        } else {
            nCore == eCore
        }
    }

    // ---------- stats ----------

    private fun day() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    /** When ON, the counter starts from zero every day. */
    fun autoReset(c: Context) = sp(c).getBoolean("autoReset", false)
    fun setAutoReset(c: Context, v: Boolean) = sp(c).edit().putBoolean("autoReset", v).apply()

    private fun rollover(c: Context) {
        if (autoReset(c) && sp(c).getString("blk_day", "") != day()) {
            sp(c).edit().putInt("blk_total", 0).putString("blk_day", day()).apply()
        }
    }

    fun blockedTotal(c: Context): Int {
        rollover(c)
        return sp(c).getInt("blk_total", 0)
    }

    fun blockedToday(c: Context) = sp(c).getInt("blk_" + day(), 0)

    fun countBlock(c: Context) {
        rollover(c)
        sp(c).edit()
            .putInt("blk_total", sp(c).getInt("blk_total", 0) + 1)
            .putInt("blk_" + day(), blockedToday(c) + 1)
            .apply()
    }

    /** Manual reset of the counters (does not touch the activity log). */
    fun resetCounters(c: Context) = sp(c).edit()
        .putInt("blk_total", 0)
        .putInt("blk_" + day(), 0)
        .putString("blk_day", day())
        .apply()

    /** Optional: auto-decline WhatsApp calls from numbers not in contacts. Default OFF. */
    fun waBlock(c: Context) = sp(c).getBoolean("waBlock", false)
    fun setWaBlock(c: Context, v: Boolean) = sp(c).edit().putBoolean("waBlock", v).apply()

    fun showDebug(c: Context) = sp(c).getBoolean("showDebug", true)
    fun setShowDebug(c: Context, v: Boolean) = sp(c).edit().putBoolean("showDebug", v).apply()

    /** When ON, only BLOCKED calls are recorded (no allowed numbers, no debug lines). */
    fun logBlockedOnly(c: Context) = sp(c).getBoolean("logBlockedOnly", false)
    fun setLogBlockedOnly(c: Context, v: Boolean) = sp(c).edit().putBoolean("logBlockedOnly", v).apply()

    /** Remove already-stored allowed/debug lines, keeping only BLOCKED ones. */
    fun purgeNonBlocked(c: Context) {
        val keep = logs(c).filter { it.drop(15).trim().startsWith("BLOCKED") }
        sp(c).edit().putString("log", keep.joinToString("\n")).apply()
    }

    fun log(c: Context, line: String) {
        if (logBlockedOnly(c) && !line.startsWith("BLOCKED")) return
        val ts = SimpleDateFormat("dd MMM HH:mm:ss", Locale.getDefault()).format(Date())
        val all = (listOf("$ts  $line") + logs(c)).take(40)
        sp(c).edit().putString("log", all.joinToString("\n")).apply()
    }

    fun logs(c: Context): List<String> =
        sp(c).getString("log", "")!!.split("\n").filter { it.isNotBlank() }

    fun clearLog(c: Context) = sp(c).edit().remove("log").apply()
}

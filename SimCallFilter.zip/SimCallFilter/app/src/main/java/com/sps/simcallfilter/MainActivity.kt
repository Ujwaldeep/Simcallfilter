package com.sps.simcallfilter

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var logView: TextView

    private val perms = arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.READ_PHONE_STATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "SIM Call Filter"
            textSize = 24f
            setTypeface(null, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Blocks incoming calls from unsaved numbers on the selected SIM only. The other SIM is untouched."
            setPadding(0, pad / 2, 0, pad)
        })

        status = TextView(this).apply { setPadding(0, 0, 0, pad) }
        root.addView(status)

        root.addView(Button(this).apply {
            text = "1. Grant contacts + phone permissions"
            setOnClickListener { requestPermissions(perms, 1) }
        })
        root.addView(Button(this).apply {
            text = "2. Set as call screening app"
            setOnClickListener { requestRole() }
        })

        root.addView(TextView(this).apply {
            text = "SIM to filter"
            setPadding(0, pad, 0, 0)
            setTypeface(null, Typeface.BOLD)
        })
        val group = RadioGroup(this).apply { orientation = LinearLayout.HORIZONTAL }
        val r1 = RadioButton(this).apply { text = "SIM 1"; id = View.generateViewId() }
        val r2 = RadioButton(this).apply { text = "SIM 2"; id = View.generateViewId() }
        group.addView(r1); group.addView(r2)
        group.check(if (Prefs.slot(this) == 0) r1.id else r2.id)
        group.setOnCheckedChangeListener { _, id ->
            Prefs.setSlot(this, if (id == r1.id) 0 else 1)
            refresh()
        }
        root.addView(group)

        root.addView(Switch(this).apply {
            text = "Filtering enabled"
            isChecked = Prefs.enabled(this@MainActivity)
            setOnCheckedChangeListener { _, v -> Prefs.setEnabled(this@MainActivity, v); refresh() }
        })
        root.addView(Switch(this).apply {
            text = "Also block private / hidden numbers"
            isChecked = Prefs.blockPrivate(this@MainActivity)
            setOnCheckedChangeListener { _, v -> Prefs.setBlockPrivate(this@MainActivity, v) }
        })

        root.addView(TextView(this).apply {
            text = "Recent decisions"
            setPadding(0, pad, 0, 0)
            setTypeface(null, Typeface.BOLD)
        })
        root.addView(Button(this).apply {
            text = "Refresh / clear log"
            setOnClickListener { Prefs.clearLog(this@MainActivity); refresh() }
        })
        logView = TextView(this).apply { typeface = Typeface.MONOSPACE; textSize = 12f }
        root.addView(logView)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        refresh()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        refresh()
    }

    private fun requestRole() {
        val rm = getSystemService(RoleManager::class.java)
        if (rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) return
        @Suppress("DEPRECATION")
        startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING), 2)
    }

    private fun refresh() {
        val permsOk = perms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
        val roleOk = getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
        status.text = buildString {
            append(if (permsOk) "✔ Permissions granted\n" else "✘ Permissions missing\n")
            append(if (roleOk) "✔ Active as call screening app\n" else "✘ Not yet set as call screening app\n")
            append("Filtering: SIM ${Prefs.slot(this@MainActivity) + 1}" +
                    if (Prefs.enabled(this@MainActivity)) "" else " (paused)")
        }
        logView.text = Prefs.logs(this).joinToString("\n").ifEmpty { "No calls screened yet." }
    }
}

package com.sps.simcallfilter

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.util.Log
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsetsController
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val perms = arrayOf(
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.POST_NOTIFICATIONS
    )

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val cIndigo = Color.parseColor("#1E3A8A")
    private val cBlue = Color.parseColor("#2563EB")
    private val cDark = Color.parseColor("#172554")
    private val cBg = Color.parseColor("#F3F4F6")
    private val cSeg = Color.parseColor("#E5E7EB")
    private val cText = Color.parseColor("#111827")
    private val cGray = Color.parseColor("#6B7280")
    private val cGreen = Color.parseColor("#16A34A")
    private val cRed = Color.parseColor("#DC2626")
    private val cAmber = Color.parseColor("#D97706")

    private class Row(val root: LinearLayout, val badge: TextView, val sub: TextView)

    private lateinit var bannerBox: LinearLayout
    private lateinit var bannerTitle: TextView
    private lateinit var bannerSub: TextView
    private lateinit var bannerStats: TextView
    private var renderWhite: (() -> Unit)? = null
    private var renderBlack: (() -> Unit)? = null
    private lateinit var rowPerm: Row
    private lateinit var rowRole: Row
    private lateinit var simBtn1: TextView
    private lateinit var simBtn2: TextView
    private lateinit var logBox: LinearLayout

    // ---------- small helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
        }

    private fun oval(color: Int): GradientDrawable =
        GradientDrawable().apply {
            this.shape = GradientDrawable.OVAL
            setColor(color)
        }

    private fun label(t: String, sizeSp: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = t
            textSize = sizeSp
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    private fun card(parent: LinearLayout): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(Color.WHITE, 16)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            elevation = dp(2).toFloat()
        }
        parent.addView(c, lp(MATCH, WRAP).apply { setMargins(dp(16), dp(12), dp(16), 0) })
        return c
    }

    private fun sectionTitle(parent: LinearLayout, t: String) {
        parent.addView(label(t.uppercase(), 12f, cGray, true).apply {
            letterSpacing = 0.08f
            setPadding(0, 0, 0, dp(6))
        })
    }

    private fun divider(parent: LinearLayout) {
        parent.addView(View(this).apply { setBackgroundColor(cSeg) }, lp(MATCH, dp(1)))
    }

    private fun setupRow(parent: LinearLayout, title: String, onClick: () -> Unit): Row {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10))
            isClickable = true
            setOnClickListener { onClick() }
        }
        val badge = TextView(this).apply {
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
        }
        root.addView(badge, lp(dp(28), dp(28)))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(label(title, 15f, cText, true))
        val sub = label("", 12f, cGray)
        col.addView(sub)
        root.addView(col, lp(0, WRAP, 1f).apply { leftMargin = dp(12) })
        root.addView(label("›", 22f, cGray))

        parent.addView(root, lp(MATCH, WRAP))
        return Row(root, badge, sub)
    }

    private fun updateRow(row: Row, ok: Boolean, okText: String, todoText: String) {
        row.badge.text = if (ok) "✓" else "!"
        row.badge.background = oval(if (ok) cGreen else cAmber)
        row.sub.text = if (ok) okText else todoText
    }

    private fun switchRow(
        parent: LinearLayout,
        title: String,
        sub: String,
        checked: Boolean,
        onChange: (Boolean) -> Unit
    ) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(label(title, 15f, cText, true))
        col.addView(label(sub, 12f, cGray))
        val sw = Switch(this).apply {
            isChecked = checked
            setOnCheckedChangeListener { _, v -> onChange(v) }
        }
        root.addView(col, lp(0, WRAP, 1f))
        root.addView(sw, lp(WRAP, WRAP).apply { leftMargin = dp(12) })
        parent.addView(root, lp(MATCH, WRAP))
    }

    private fun simButton(t: String, slot: Int): TextView =
        TextView(this).apply {
            text = t
            gravity = Gravity.CENTER
            textSize = 15f
            setTypeface(null, Typeface.BOLD)
            setOnClickListener {
                Prefs.setSlot(this@MainActivity, slot)
                refresh()
            }
        }

    private fun numberListCard(
        parent: LinearLayout,
        title: String,
        desc: String,
        getList: () -> List<String>,
        add: (String) -> Boolean,
        remove: (String) -> Unit
    ): () -> Unit {
        val c = card(parent)
        sectionTitle(c, title)
        c.addView(label(desc, 12f, cGray).apply { setPadding(0, 0, 0, dp(8)) })

        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val input = EditText(this).apply {
            hint = "+91 98765 43210  or  1800*"
            inputType = InputType.TYPE_CLASS_PHONE
            textSize = 14f
            setSingleLine()
        }
        val addBtn = Button(this).apply { text = "Add" }
        inputRow.addView(input, lp(0, WRAP, 1f))
        inputRow.addView(addBtn, lp(WRAP, WRAP))
        c.addView(inputRow, lp(MATCH, WRAP))

        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c.addView(box, lp(MATCH, WRAP))

        lateinit var render: () -> Unit
        render = {
            box.removeAllViews()
            val items = getList()
            if (items.isEmpty()) {
                box.addView(label("No numbers yet", 13f, cGray).apply { setPadding(0, dp(8), 0, 0) })
            }
            for (e in items) {
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(6), 0, dp(6))
                }
                row.addView(label(e, 15f, cText), lp(0, WRAP, 1f))
                row.addView(label("✕", 16f, cRed, true).apply {
                    setPadding(dp(14), dp(4), dp(4), dp(4))
                    setOnClickListener {
                        remove(e)
                        render()
                    }
                })
                box.addView(row)
            }
        }

        addBtn.setOnClickListener {
            val v = input.text.toString().trim()
            if (add(v)) {
                input.setText("")
                render()
            } else {
                Toast.makeText(this, "Enter a valid number", Toast.LENGTH_SHORT).show()
            }
        }
        render()
        return render
    }

    // ---------- UI ----------

    private var crashShown = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val saved = getSharedPreferences("crash", MODE_PRIVATE).getString("trace", null)
        if (saved != null) {
            crashShown = true
            showCrash("Crash from the last run:\n\n$saved")
            return
        }
        try {
            buildUi()
        } catch (e: Throwable) {
            crashShown = true
            showCrash("Error while building the screen:\n\n" + Log.getStackTraceString(e).take(3500))
        }
    }

    private fun showCrash(trace: String) {
        val pad = dp(16)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        col.addView(label("SIM Call Filter hit an error", 20f, cRed, true))
        col.addView(
            label("Tap Copy error and send it to Claude.", 13f, cGray)
                .apply { setPadding(0, dp(6), 0, dp(12)) }
        )
        col.addView(TextView(this).apply {
            text = trace
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setTextColor(cText)
            setTextIsSelectable(true)
        })
        col.addView(Button(this).apply {
            text = "Copy error"
            setOnClickListener {
                getSystemService(ClipboardManager::class.java)
                    .setPrimaryClip(ClipData.newPlainText("error", trace))
            }
        })
        col.addView(Button(this).apply {
            text = "Clear and try again"
            setOnClickListener {
                getSharedPreferences("crash", MODE_PRIVATE).edit().clear().commit()
                recreate()
            }
        })
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(28))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR, intArrayOf(cIndigo, cBlue)
            ).apply {
                val r = dp(24).toFloat()
                cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
            }
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.ic_logo)
            background = shape(Color.parseColor("#33FFFFFF"), 16)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        header.addView(logo, lp(dp(56), dp(56)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(label("SIM Call Filter", 22f, Color.WHITE, true))
        titles.addView(label("Block unsaved numbers on one SIM", 13f, Color.parseColor("#CCFFFFFF")))
        header.addView(titles, lp(0, WRAP, 1f).apply { leftMargin = dp(14) })
        root.addView(header, lp(MATCH, WRAP))

        // Status banner
        bannerBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            elevation = dp(3).toFloat()
        }
        bannerTitle = label("", 18f, Color.WHITE, true)
        bannerSub = label("", 13f, Color.parseColor("#E6FFFFFF")).apply { setPadding(0, dp(4), 0, 0) }
        bannerBox.addView(bannerTitle)
        bannerBox.addView(bannerSub)
        bannerStats = label("", 12f, Color.parseColor("#CCFFFFFF"))
        val statsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        statsRow.addView(bannerStats, lp(0, WRAP, 1f))
        statsRow.addView(label("RESET", 12f, Color.WHITE, true).apply {
            setPadding(dp(12), dp(4), 0, dp(4))
            setOnClickListener {
                Prefs.resetCounters(this@MainActivity)
                refresh()
            }
        })
        bannerBox.addView(statsRow)
        root.addView(bannerBox, lp(MATCH, WRAP).apply { setMargins(dp(16), dp(-14), dp(16), 0) })

        // Setup card
        val setup = card(root)
        sectionTitle(setup, "Setup")
        rowPerm = setupRow(setup, "Permissions") { requestPermissions(perms, 1) }
        divider(setup)
        rowRole = setupRow(setup, "Call screening app") { requestRole() }

        // SIM selector card
        val simCard = card(root)
        sectionTitle(simCard, "SIM to filter")
        val seg = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = shape(cSeg, 12)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        simBtn1 = simButton("SIM 1", 0)
        simBtn2 = simButton("SIM 2", 1)
        seg.addView(simBtn1, lp(0, dp(44), 1f))
        seg.addView(simBtn2, lp(0, dp(44), 1f))
        simCard.addView(seg, lp(MATCH, WRAP))
        simCard.addView(
            label("Unsaved numbers calling this SIM are rejected. The other SIM is never touched.", 12f, cGray)
                .apply { setPadding(0, dp(10), 0, 0) }
        )

        // Whitelist / blocklist cards
        renderWhite = numberListCard(
            root, "Whitelist (always allow)",
            "These numbers always ring, even if unsaved. Add a full number, or a prefix ending in * (like 1800*).",
            { Prefs.whitelist(this) }, { Prefs.addWhitelist(this, it) }, { Prefs.removeWhitelist(this, it) }
        )
        renderBlack = numberListCard(
            root, "Blocklist (always block)",
            "These numbers are always rejected on the filtered SIM, even if saved. Prefix with * works too.",
            { Prefs.blocklist(this) }, { Prefs.addBlocklist(this, it) }, { Prefs.removeBlocklist(this, it) }
        )

        // Options card
        val opts = card(root)
        sectionTitle(opts, "Options")
        switchRow(opts, "Filtering enabled", "Turn off to let everything through", Prefs.enabled(this)) {
            Prefs.setEnabled(this, it)
            refresh()
        }
        divider(opts)
        switchRow(opts, "Block hidden numbers", "Private / unknown caller ID", Prefs.blockPrivate(this)) {
            Prefs.setBlockPrivate(this, it)
        }
        divider(opts)
        switchRow(
            opts, "Block unknown WhatsApp calls",
            "Declines WhatsApp calls from numbers not in your contacts, on any SIM. Needs notification access.",
            Prefs.waBlock(this)
        ) {
            Prefs.setWaBlock(this, it)
            if (it) enableWhatsAppBlocking()
        }
        divider(opts)
        switchRow(opts, "Hide blocked calls", "No ring, no call log entry, no missed-call alert", Prefs.hideBlocked(this)) {
            Prefs.setHideBlocked(this, it)
        }
        divider(opts)
        switchRow(opts, "Reset counter every day", "Counter starts from zero each morning", Prefs.autoReset(this)) {
            Prefs.setAutoReset(this, it)
            refresh()
        }
        divider(opts)
        switchRow(opts, "Always-on mode", "Uses more battery. Only for if blocking fails without it", Prefs.alwaysOn(this)) {
            Prefs.setAlwaysOn(this, it)
            startWatcher()
        }
        divider(opts)
        switchRow(
            opts, "Log blocked calls only",
            "Don't record allowed numbers or debug lines. Existing ones are removed.",
            Prefs.logBlockedOnly(this)
        ) {
            Prefs.setLogBlockedOnly(this, it)
            if (it) Prefs.purgeNonBlocked(this)
            refresh()
        }
        divider(opts)
        switchRow(opts, "Show debug lines", "Extra detail in the activity log", Prefs.showDebug(this)) {
            Prefs.setShowDebug(this, it)
            refresh()
        }

        // Activity card
        val act = card(root)
        val actHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        actHeader.addView(
            label("RECENT ACTIVITY", 12f, cGray, true).apply { letterSpacing = 0.08f },
            lp(0, WRAP, 1f)
        )
        actHeader.addView(label("Clear", 13f, cBlue, true).apply {
            setPadding(dp(8), dp(4), 0, dp(4))
            setOnClickListener {
                Prefs.clearLog(this@MainActivity)
                refresh()
            }
        })
        act.addView(actHeader, lp(MATCH, WRAP))
        logBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        act.addView(logBox, lp(MATCH, WRAP))

        root.addView(
            label("Blocked calls are rejected before they ring.", 12f, cGray).apply {
                gravity = Gravity.CENTER
                setPadding(dp(16), dp(16), dp(16), dp(28))
            },
            lp(MATCH, WRAP)
        )

        setContentView(ScrollView(this).apply {
            setBackgroundColor(cBg)
            isFillViewport = true
            addView(root)
        })

        runCatching {
            window.statusBarColor = cDark
            window.insetsController?.setSystemBarsAppearance(
                0, WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
            )
        }
    }

    // ---------- lifecycle / actions ----------

    override fun onResume() {
        super.onResume()
        if (crashShown) return
        startWatcher()
        refresh()
    }

    private fun enableWhatsAppBlocking() {
        val cn = android.content.ComponentName(this, WhatsAppCallService::class.java)
        val granted = getSystemService(android.app.NotificationManager::class.java)
            .isNotificationListenerAccessGranted(cn)
        if (granted) {
            runCatching { android.service.notification.NotificationListenerService.requestRebind(cn) }
            Toast.makeText(this, "WhatsApp call blocking is on", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(
                this,
                "Turn on notification access for SIM Call Filter, then come back",
                Toast.LENGTH_LONG
            ).show()
            runCatching {
                startActivity(Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }
    }

    private fun startWatcher() {
        if (!Prefs.alwaysOn(this)) {
            runCatching { stopService(Intent(this, RingWatcherService::class.java)) }
            return
        }
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            runCatching { startForegroundService(Intent(this, RingWatcherService::class.java)) }
        }
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        if (crashShown) return
        startWatcher()
        refresh()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (!crashShown) refresh()
    }

    private fun requestRole() {
        val rm = getSystemService(RoleManager::class.java)
        if (rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) return
        @Suppress("DEPRECATION")
        startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING), 2)
    }

    private fun refresh() {
        val permsOk = perms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
        val roleOk = getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_CALL_SCREENING)

        updateRow(rowPerm, permsOk, "Contacts, phone and notifications granted",
            "Tap to grant contacts, phone and notifications")
        updateRow(rowRole, roleOk, "SIM Call Filter is your call screening app",
            "Tap to make SIM Call Filter your call screening app")

        val slot = Prefs.slot(this)
        val enabled = Prefs.enabled(this)
        when {
            !permsOk || !roleOk -> {
                bannerBox.background = shape(cAmber, 16)
                bannerTitle.text = "Setup needed"
                bannerSub.text = "Finish the steps below to start filtering."
            }
            !enabled -> {
                bannerBox.background = shape(cGray, 16)
                bannerTitle.text = "Paused"
                bannerSub.text = "All calls are going through on both SIMs."
            }
            else -> {
                bannerBox.background = shape(cGreen, 16)
                bannerTitle.text = "Protection active"
                bannerSub.text = "Unsaved numbers on SIM ${slot + 1} are rejected. SIM ${2 - slot} is untouched."
            }
        }

        listOf(simBtn1 to 0, simBtn2 to 1).forEach { (btn, s) ->
            val sel = slot == s
            btn.background = if (sel) shape(cIndigo, 9) else null
            btn.setTextColor(if (sel) Color.WHITE else cGray)
        }

        bannerStats.text = if (Prefs.autoReset(this)) {
            "Blocked today: ${Prefs.blockedToday(this)}"
        } else {
            "Blocked today: ${Prefs.blockedToday(this)}   •   All time: ${Prefs.blockedTotal(this)}"
        }
        renderWhite?.invoke()
        renderBlack?.invoke()
        refreshLog()
    }

    private fun refreshLog() {
        logBox.removeAllViews()
        val lines = Prefs.logs(this).filter { Prefs.showDebug(this) || !it.contains("DEBUG") }
        if (lines.isEmpty()) {
            logBox.addView(label("No calls screened yet.", 13f, cGray).apply { setPadding(0, dp(8), 0, 0) })
            return
        }
        for (l in lines) {
            val ts = l.take(15)
            val msg = l.drop(15).trim()
            val color = when {
                msg.startsWith("BLOCKED") -> cRed
                msg.startsWith("ALLOWED") -> cGreen
                else -> cGray
            }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(7), 0, dp(7))
            }
            row.addView(label(ts, 11f, cGray))
            row.addView(label(msg, 13f, color, msg.startsWith("BLOCKED")))
            if (msg.startsWith("BLOCKED")) {
                val num = msg.substringAfterLast(") ").trim()
                if (num.count { it.isDigit() } >= 5) {
                    row.addView(label("Allow this number", 12f, cBlue, true).apply {
                        setPadding(0, dp(4), 0, dp(2))
                        setOnClickListener {
                            Prefs.addWhitelist(this@MainActivity, num)
                            Toast.makeText(this@MainActivity, "Added to whitelist", Toast.LENGTH_SHORT).show()
                            refresh()
                        }
                    })
                }
            }
            logBox.addView(row)
        }
    }
}

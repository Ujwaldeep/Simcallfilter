package com.sps.simcallfilter

import android.net.Uri
import android.provider.ContactsContract
import android.telecom.Call
import android.telecom.CallScreeningService
import android.telecom.PhoneAccountHandle
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager

class SimCallScreeningService : CallScreeningService() {

    override fun onScreenCall(details: Call.Details) {
        val allow = CallResponse.Builder().build()

        try {
            if (details.callDirection != Call.Details.DIRECTION_INCOMING || !Prefs.enabled(this)) {
                respondToCall(details, allow)
                return
            }

            val slot = slotOf(details.accountHandle)
            val target = Prefs.slot(this)
            val number = details.handle?.schemeSpecificPart?.takeIf { it.isNotBlank() }

            if (slot == -1) {
                // Could not tell which SIM. Fail open so we never block the wrong SIM.
                Prefs.log(this, "ALLOWED (SIM unknown) ${number ?: "private"}")
                respondToCall(details, allow)
                return
            }

            if (slot != target) {
                Prefs.log(this, "ALLOWED (SIM ${slot + 1}, not filtered) ${number ?: "private"}")
                respondToCall(details, allow)
                return
            }

            val shouldBlock = if (number == null) {
                Prefs.blockPrivate(this)
            } else {
                !isSaved(number)
            }

            if (shouldBlock) {
                Prefs.log(this, "BLOCKED (SIM ${slot + 1}) ${number ?: "private"}")
                respondToCall(
                    details,
                    CallResponse.Builder()
                        .setDisallowCall(true)
                        .setRejectCall(true)
                        .setSkipNotification(true)
                        .setSkipCallLog(false) // keep it in the call log as rejected
                        .build()
                )
            } else {
                Prefs.log(this, "ALLOWED (SIM ${slot + 1}, saved) $number")
                respondToCall(details, allow)
            }
        } catch (e: Exception) {
            Prefs.log(this, "ALLOWED (error: ${e.javaClass.simpleName})")
            respondToCall(details, allow)
        }
    }

    /** Returns 0-based SIM slot for the call's phone account, or -1 if it can't be determined. */
    private fun slotOf(handle: PhoneAccountHandle?): Int {
        if (handle == null) return -1
        val sm = getSystemService(SubscriptionManager::class.java) ?: return -1

        runCatching {
            val tm = getSystemService(TelephonyManager::class.java)
            val subId = tm.createForPhoneAccountHandle(handle)?.subscriptionId
            if (subId != null && subId != SubscriptionManager.INVALID_SUBSCRIPTION_ID) {
                sm.getActiveSubscriptionInfo(subId)?.let { return it.simSlotIndex }
            }
        }

        // Fallback: some devices use the subscription id or ICCID as the account id.
        runCatching {
            sm.activeSubscriptionInfoList?.forEach {
                if (handle.id == it.subscriptionId.toString() || handle.id == it.iccId) {
                    return it.simSlotIndex
                }
            }
        }
        return -1
    }

    private fun isSaved(number: String): Boolean {
        val uri = Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
            Uri.encode(number)
        )
        contentResolver.query(
            uri, arrayOf(ContactsContract.PhoneLookup._ID), null, null, null
        )?.use { return it.count > 0 }
        return false
    }
}

package com.sps.simcallfilter

import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.telecom.Call
import android.telecom.CallScreeningService
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager

class SimCallScreeningService : CallScreeningService() {

    private val handler = Handler(Looper.getMainLooper())
    private val allow get() = CallResponse.Builder().build()

    override fun onScreenCall(details: Call.Details) {
        try {
            if (details.callDirection != Call.Details.DIRECTION_INCOMING || !Prefs.enabled(this)) {
                respondToCall(details, allow)
                return
            }
            val direct = slotOf(details.accountHandle)
            if (direct != -1) {
                decide(details, direct, "call info")
            } else {
                waitForRingSlot(details, System.currentTimeMillis(), 0)
            }
        } catch (e: Exception) {
            Prefs.log(this, "ALLOWED (error: ${e.javaClass.simpleName})")
            respondToCall(details, allow)
        }
    }

    /** Fallback: wait up to ~3s for the PHONE_STATE broadcast to tell us the ringing SIM. */
    private fun waitForRingSlot(details: Call.Details, started: Long, attempt: Int) {
        try {
            val s = Prefs.ringSlotSince(this, started - 4000)
            if (s != -1) {
                decide(details, s, "ring broadcast")
                return
            }
            if (attempt >= 12) {
                val number = details.handle?.schemeSpecificPart ?: "private"
                Prefs.log(
                    this,
                    "ALLOWED (SIM unknown) $number | handle=${details.accountHandle?.id ?: "null"}" +
                        " extras=${dump(details.extras)} intent=${dump(details.intentExtras)}"
                )
                respondToCall(details, allow)
                return
            }
            handler.postDelayed({ waitForRingSlot(details, started, attempt + 1) }, 250)
        } catch (e: Exception) {
            Prefs.log(this, "ALLOWED (error: ${e.javaClass.simpleName})")
            respondToCall(details, allow)
        }
    }

    private fun decide(details: Call.Details, slot: Int, via: String) {
        try {
            val target = Prefs.slot(this)
            val number = details.handle?.schemeSpecificPart?.takeIf { it.isNotBlank() }
            val shown = number ?: "private"

            if (slot != target) {
                Prefs.log(this, "ALLOWED (SIM ${slot + 1}, not filtered, via $via) $shown")
                respondToCall(details, allow)
                return
            }

            val shouldBlock = if (number == null) Prefs.blockPrivate(this) else !isSaved(number)

            if (shouldBlock) {
                Prefs.log(this, "BLOCKED (SIM ${slot + 1}, via $via) $shown")
                respondToCall(
                    details,
                    CallResponse.Builder()
                        .setDisallowCall(true)
                        .setRejectCall(true)
                        .setSkipNotification(true)
                        .setSkipCallLog(false)
                        .build()
                )
            } else {
                Prefs.log(this, "ALLOWED (SIM ${slot + 1}, saved, via $via) $shown")
                respondToCall(details, allow)
            }
        } catch (e: Exception) {
            Prefs.log(this, "ALLOWED (error: ${e.javaClass.simpleName})")
            respondToCall(details, allow)
        }
    }

    /** 0-based SIM slot for the call's phone account, or -1 if it can't be determined. */
    private fun slotOf(handle: PhoneAccountHandle?): Int {
        if (handle == null) return -1
        val sm = getSystemService(SubscriptionManager::class.java) ?: return -1

        runCatching {
            val tm = getSystemService(TelephonyManager::class.java)
            val subId = tm.createForPhoneAccountHandle(handle)?.subscriptionId
            if (subId != null && subId != SubscriptionManager.INVALID_SUBSCRIPTION_ID) {
                sm.getActiveSubscriptionInfo(subId)?.let { return it.simSlotIndex }
            }
        }

        runCatching {
            sm.activeSubscriptionInfoList?.forEach {
                if (handle.id == it.subscriptionId.toString() || handle.id == it.iccId) {
                    return it.simSlotIndex
                }
            }
        }

        runCatching {
            val label = getSystemService(TelecomManager::class.java)
                .getPhoneAccount(handle)?.label?.toString()
            if (label != null) {
                val m = sm.activeSubscriptionInfoList?.filter {
                    it.displayName?.toString() == label || it.carrierName?.toString() == label
                }
                if (m != null && m.size == 1) return m[0].simSlotIndex
            }
        }
        return -1
    }

    private fun dump(b: android.os.Bundle?): String =
        b?.keySet()?.joinToString { k -> "$k=${b.get(k)}" }?.take(300) ?: "null"

    private fun isSaved(number: String): Boolean {
        val uri = Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
            Uri.encode(number)
        )
        contentResolver.query(
            uri, arrayOf(ContactsContract.PhoneLookup._ID), null, null, null
        )?.use { return it.count > 0 }
        return false
    }
}

package com.sps.simcallfilter

import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.telecom.Call
import android.telecom.CallScreeningService
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.telephony.SubscriptionManager
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager

class SimCallScreeningService : CallScreeningService() {

    private val handler = Handler(Looper.getMainLooper())
    private var screenStart = 0L
    private val ringing = mutableSetOf<Int>()
    private val listeners = mutableListOf<Pair<TelephonyManager, TelephonyCallback>>()
    private val allow get() = CallResponse.Builder().build()

    override fun onScreenCall(details: Call.Details) {
        screenStart = System.currentTimeMillis()
        try {
            if (details.callDirection != Call.Details.DIRECTION_INCOMING || !Prefs.enabled(this)) {
                respondToCall(details, allow)
                return
            }
            val direct = slotOf(details.accountHandle)
            if (direct != -1) {
                decide(details, direct, "call info")
            } else {
                startListening()
                waitForRingSlot(details, System.currentTimeMillis(), 0)
            }
        } catch (e: Exception) {
            Prefs.log(this, "ALLOWED (error: ${e.javaClass.simpleName})")
            respondToCall(details, allow)
        }
    }

    /** Fallback: listen briefly (up to ~3s) to each SIM's call state to learn which SIM is ringing. */
    private fun waitForRingSlot(details: Call.Details, started: Long, attempt: Int) {
        try {
            val s = when {
                ringing.size == 1 -> ringing.first()
                ringing.isEmpty() -> Prefs.ringSlotSince(this, started - 4000)
                else -> -1
            }
            if (s != -1) {
                stopListening()
                decide(details, s, "SIM listener")
                return
            }
            if (attempt >= 75) {
                stopListening()
                val number = details.handle?.schemeSpecificPart ?: "private"
                Prefs.log(
                    this,
                    "ALLOWED (SIM unknown) $number | ringing=$ringing handle=${details.accountHandle?.id ?: "null"}"
                )
                if (!Prefs.alwaysOn(this)) {
                    // Self-heal: switch to the proven always-on method for future calls.
                    Prefs.setAlwaysOn(this, true)
                    Prefs.log(this, "DEBUG battery-saver detection missed; switched to always-on mode")
                    runCatching { startForegroundService(Intent(this, RingWatcherService::class.java)) }
                }
                respondToCall(details, allow)
                return
            }
            handler.postDelayed({ waitForRingSlot(details, started, attempt + 1) }, 40)
        } catch (e: Exception) {
            stopListening()
            Prefs.log(this, "ALLOWED (error: ${e.javaClass.simpleName})")
            respondToCall(details, allow)
        }
    }

    private inner class RingCb(val slot: Int) :
        TelephonyCallback(), TelephonyCallback.CallStateListener {
        override fun onCallStateChanged(state: Int) {
            if (state == TelephonyManager.CALL_STATE_RINGING) ringing.add(slot)
        }
    }

    /** Start listening to every active SIM. Registered only while a call is being screened. */
    private fun startListening() {
        stopListening()
        ringing.clear()
        val sm = getSystemService(SubscriptionManager::class.java)
        val base = getSystemService(TelephonyManager::class.java)
        val subs = try {
            sm.activeSubscriptionInfoList
        } catch (e: SecurityException) {
            null
        }
        if (subs == null) return
        for (sub in subs) {
            try {
                val tm = base.createForSubscriptionId(sub.subscriptionId)
                val cb = RingCb(sub.simSlotIndex)
                tm.registerTelephonyCallback(mainExecutor, cb)
                listeners.add(tm to cb)
            } catch (e: Exception) {
            }
        }
    }

    private fun stopListening() {
        listeners.forEach { (tm, cb) -> runCatching { tm.unregisterTelephonyCallback(cb) } }
        listeners.clear()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopListening()
        super.onDestroy()
    }

    private fun decide(details: Call.Details, slot: Int, via: String) {
        try {
            val target = Prefs.slot(this)
            val number = details.handle?.schemeSpecificPart?.takeIf { it.isNotBlank() }
            val shown = number ?: "private"

            if (slot != target) {
                Prefs.log(this, "ALLOWED (SIM ${slot + 1}, not filtered, via $via) $shown")
                respondToCall(details, allow)
                return
            }

            // Priority: whitelist > blocklist > saved contact > block unsaved
            var why = "saved"
            val shouldBlock: Boolean
            if (number == null) {
                shouldBlock = Prefs.blockPrivate(this)
            } else if (Prefs.whitelist(this).any { Prefs.matches(it, number) }) {
                why = "whitelisted"
                shouldBlock = false
            } else if (Prefs.blocklist(this).any { Prefs.matches(it, number) }) {
                why = "blocklist"
                shouldBlock = true
            } else {
                shouldBlock = !isSaved(number)
            }

            if (shouldBlock) {
                Prefs.countBlock(this)
                Prefs.log(
                    this,
                    "BLOCKED (SIM ${slot + 1}, ${if (why == "blocklist") "blocklist" else "via $via"}, ${System.currentTimeMillis() - screenStart}ms) $shown"
                )
                respondToCall(
                    details,
                    CallResponse.Builder()
                        .setDisallowCall(true)
                        .setRejectCall(true)
                        .setSilenceCall(true)
                        .setSkipNotification(true)
                        .setSkipCallLog(Prefs.hideBlocked(this))
                        .build()
                )
            } else {
                Prefs.log(this, "ALLOWED (SIM ${slot + 1}, $why, via $via) $shown")
                respondToCall(details, allow)
            }
        } catch (e: Exception) {
            Prefs.log(this, "ALLOWED (error: ${e.javaClass.simpleName})")
            respondToCall(details, allow)
        }
    }

    /** 0-based SIM slot for the call's phone account, or -1 if it can't be determined. */
    private fun slotOf(handle: PhoneAccountHandle?): Int {
        if (handle == null) return -1
        val sm = getSystemService(SubscriptionManager::class.java) ?: return -1

        runCatching {
            val tm = getSystemService(TelephonyManager::class.java)
            val subId = tm.createForPhoneAccountHandle(handle)?.subscriptionId
            if (subId != null && subId != SubscriptionManager.INVALID_SUBSCRIPTION_ID) {
                sm.getActiveSubscriptionInfo(subId)?.let { return it.simSlotIndex }
            }
        }

        runCatching {
            sm.activeSubscriptionInfoList?.forEach {
                if (handle.id == it.subscriptionId.toString() || handle.id == it.iccId) {
                    return it.simSlotIndex
                }
            }
        }

        runCatching {
            val label = getSystemService(TelecomManager::class.java)
                .getPhoneAccount(handle)?.label?.toString()
            if (label != null) {
                val m = sm.activeSubscriptionInfoList?.filter {
                    it.displayName?.toString() == label || it.carrierName?.toString() == label
                }
                if (m != null && m.size == 1) return m[0].simSlotIndex
            }
        }
        return -1
    }

    private fun dump(b: android.os.Bundle?): String =
        b?.keySet()?.joinToString { k -> "$k=${b.get(k)}" }?.take(300) ?: "null"

    private fun isSaved(number: String): Boolean {
        val uri = Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
            Uri.encode(number)
        )
        contentResolver.query(
            uri, arrayOf(ContactsContract.PhoneLookup._ID), null, null, null
        )?.use { return it.count > 0 }
        return false
    }
}
